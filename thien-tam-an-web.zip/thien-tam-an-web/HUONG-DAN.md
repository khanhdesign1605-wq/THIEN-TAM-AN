# Đưa blog Thiện Tâm An lên internet

Blog gồm 2 phần, đều dùng gói **miễn phí**:

- **Supabase**: kho lưu bài viết và tài khoản người viết.
- **Netlify**: nơi đặt trang web để mọi người truy cập.

Thư mục này có:

| Thư mục / tệp | Dùng để |
|---|---|
| `website/` | Toàn bộ trang web. Sẽ kéo thả lên Netlify. |
| `website/config.js` | Nơi dán 2 thông số kết nối Supabase. |
| `supabase/1-cau-truc-va-phan-quyen.sql` | Tạo kho dữ liệu và phân quyền. |
| `supabase/2-bai-viet-hien-co.sql` | Chuyển 4 bài đang có sang web mới. |

**Phân quyền trên web mới**

- **Người đọc**: không cần tài khoản, xem mọi bài đã đăng.
- **Người viết**: đăng nhập bằng email, viết bài, lưu nháp, đăng, sửa; chỉ xoá được bài của mình.
- **Quản trị** (bạn, `catkhanh1605@gmail.com`): làm mọi việc, thêm/bớt người viết ở trang **Thành viên**.

> Tên các nút trên Supabase/Netlify có thể hơi khác theo thời gian, nhưng vị trí thường giống mô tả dưới đây.

---

## Bước 1. Tạo kho dữ liệu trên Supabase (khoảng 10 phút)

1. Vào **supabase.com** → **Start your project** → đăng ký (dùng GitHub hoặc email).
2. Bấm **New project**:
   - Name: `thien-tam-an`
   - Database Password: bấm *Generate*, rồi **lưu mật khẩu này lại**.
   - Region: **Southeast Asia (Singapore)** cho nhanh ở Việt Nam.
   - Bấm **Create new project**, đợi 1–2 phút.
3. Ở menu trái chọn **SQL Editor** → **New query**. Mở tệp `supabase/1-cau-truc-va-phan-quyen.sql` bằng Notepad/TextEdit, chép **toàn bộ**, dán vào, bấm **Run**. Thấy *Success* là được.
4. Làm tương tự với tệp `supabase/2-bai-viet-hien-co.sql` (tệp này lớn vì chứa ảnh bìa; nếu trình duyệt chậm, có thể chép từng đoạn bắt đầu bằng dòng `-- Tên bài` và chạy lần lượt).
5. Vào **Project Settings** (bánh răng) → **API** / **API Keys**. Chép 2 giá trị:
   - **Project URL** (dạng `https://abcxyz.supabase.co`)
   - Khoá **anon public** (hoặc **Publishable key**). *Không* dùng khoá `service_role` / `secret`.
6. Mở tệp `website/config.js`, dán 2 giá trị vào chỗ `DAN_PROJECT_URL_VAO_DAY` và `DAN_ANON_KEY_VAO_DAY`, giữ nguyên dấu ngoặc kép, lưu tệp.

## Bước 2. Đưa trang web lên Netlify (5 phút)

1. Vào **app.netlify.com/drop**, đăng ký tài khoản.
2. Kéo **cả thư mục `website`** thả vào khung trên trang. Đợi vài giây, Netlify cho bạn một địa chỉ dạng `https://ten-ngau-nhien.netlify.app`.
3. Đổi tên cho dễ nhớ: **Site configuration** → **Change site name** → ví dụ `thientaman` → địa chỉ thành `https://thientaman.netlify.app`.

## Bước 3. Nối đăng nhập với trang web

1. Quay lại Supabase → **Authentication** → **URL Configuration**.
2. **Site URL**: dán địa chỉ Netlify của bạn (ví dụ `https://thientaman.netlify.app`).
3. **Redirect URLs** → **Add URL** → dán cùng địa chỉ đó → **Save**.

## Bước 4. Cài hộp thư gửi link đăng nhập (quan trọng)

Hệ thống gửi email có sẵn của Supabase chỉ gửi được rất ít thư mỗi giờ, và **thường chỉ gửi tới email của chủ dự án**. Để người viết khác nhận được link đăng nhập, hãy cho Supabase gửi thư qua Gmail của nhóm:

1. Với tài khoản Gmail sẽ dùng để gửi thư: bật **Xác minh 2 bước**, rồi vào **myaccount.google.com/apppasswords** tạo một **Mật khẩu ứng dụng** (16 ký tự).
2. Supabase → **Authentication** → **Emails** (hoặc **Settings**) → **SMTP Settings** → bật **Custom SMTP**:
   - Sender email: địa chỉ Gmail đó · Sender name: `Thiện Tâm An`
   - Host: `smtp.gmail.com` · Port: `465`
   - Username: địa chỉ Gmail đó · Password: mật khẩu ứng dụng 16 ký tự
   - **Save**.

(Chỉ mình bạn viết bài thì có thể tạm bỏ qua bước này.)

## Bước 5. Đăng nhập lần đầu

1. Mở trang web → cuối trang bấm **Dành cho người viết**.
2. Nhập `catkhanh1605@gmail.com` → **Gửi link đăng nhập**.
3. Mở email, bấm vào link **trên cùng thiết bị/trình duyệt**. Bạn sẽ thấy thanh trên cùng ghi **Quản trị**, cùng các nút *Viết bài mới*, *Thành viên*, *Đăng xuất*.

## Thêm người cùng viết

1. Đăng nhập → **Thành viên** → nhập email của họ, chọn **Người viết** (hoặc **Quản trị**) → **Thêm**.
2. Nhắn họ vào trang web → **Dành cho người viết** → nhập đúng email đó để nhận link.
3. Muốn gỡ quyền: bấm **Gỡ** cạnh email. Bài họ đã viết vẫn được giữ.

## Chia sẻ blog

Gửi địa chỉ Netlify cho bất kỳ ai. Trong mỗi bài có nút **Sao chép link bài viết** để gửi riêng từng bài lên Facebook, Zalo.

---

## Câu hỏi thường gặp

**Muốn có tên miền riêng (ví dụ thientaman.vn)?** Mua tên miền ở nhà cung cấp tên miền, rồi vào Netlify → **Domain management** → **Add a domain** và làm theo hướng dẫn. Nhớ cập nhật lại **Site URL** và **Redirect URLs** ở Bước 3 bằng tên miền mới.

**Trang báo "không tải được bài viết" sau một thời gian dài không ai dùng?** Dự án Supabase miễn phí có thể bị tạm dừng khi không có hoạt động trong khoảng một tuần. Đăng nhập supabase.com, mở dự án và bấm **Restore**.

**Muốn sửa giao diện hoặc thêm tính năng?** Sửa tệp trong `website/` rồi vào Netlify → dự án → **Deploys** → kéo thả lại thư mục `website`. Bài viết không bị ảnh hưởng vì nằm ở Supabase.

**Khoá trong config.js có an toàn không?** Có. Đó là khoá công khai, được thiết kế để đặt trên web. Quyền đọc/ghi được bảo vệ bởi các quy tắc trong tệp SQL: khách chỉ đọc bài đã đăng, chỉ email trong danh sách Thành viên mới ghi được.
