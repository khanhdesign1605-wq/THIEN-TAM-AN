-- =============================================================
--  THIỆN TÂM AN — Cấu trúc dữ liệu & phân quyền
--  Chạy MỘT LẦN trong Supabase: SQL Editor > New query > dán toàn bộ > Run
-- =============================================================

-- 1) Danh sách thành viên được phép viết bài
create table if not exists public.members (
  email      text primary key,
  role       text not null check (role in ('writer','admin')),
  created_at timestamptz not null default now()
);

-- 2) Bài viết (cả bản nháp và bài đã đăng)
create table if not exists public.posts (
  id           uuid primary key default gen_random_uuid(),
  status       text not null default 'draft' check (status in ('draft','published')),
  title        text not null default '',
  cat          text not null default 'trip' check (cat in ('trip','tyh','news')),
  date         date,
  place        text not null default '',
  highlight    text not null default '',
  excerpt      text not null default '',
  body         text not null default '',
  cover        text not null default '',
  author_email text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists posts_status_date on public.posts (status, date desc);

-- 3) Hàm cho biết vai trò của người đang đăng nhập (null = khách / người đọc)
create or replace function public.my_role()
returns text language sql stable security definer set search_path = public as $$
  select role from public.members
  where email = lower(coalesce(auth.jwt() ->> 'email', ''))
$$;

-- 4) Bật bảo vệ theo dòng (Row Level Security)
alter table public.posts   enable row level security;
alter table public.members enable row level security;

drop policy if exists "Đọc bài (khách: bài đã đăng)" on public.posts;
create policy "Đọc bài (khách: bài đã đăng)" on public.posts
  for select using (status = 'published' or public.my_role() is not null);

drop policy if exists "Người viết thêm bài" on public.posts;
create policy "Người viết thêm bài" on public.posts
  for insert to authenticated with check (public.my_role() is not null);

drop policy if exists "Người viết sửa bài" on public.posts;
create policy "Người viết sửa bài" on public.posts
  for update to authenticated using (public.my_role() is not null) with check (public.my_role() is not null);

drop policy if exists "Quản trị hoặc tác giả xoá bài" on public.posts;
create policy "Quản trị hoặc tác giả xoá bài" on public.posts
  for delete to authenticated using (
    public.my_role() = 'admin'
    or (public.my_role() is not null and author_email = lower(auth.jwt() ->> 'email'))
  );

drop policy if exists "Xem danh sách thành viên" on public.members;
create policy "Xem danh sách thành viên" on public.members
  for select to authenticated using (public.my_role() = 'admin' or email = lower(auth.jwt() ->> 'email'));

drop policy if exists "Quản trị thêm thành viên" on public.members;
create policy "Quản trị thêm thành viên" on public.members
  for insert to authenticated with check (public.my_role() = 'admin');

drop policy if exists "Quản trị đổi vai trò" on public.members;
create policy "Quản trị đổi vai trò" on public.members
  for update to authenticated using (public.my_role() = 'admin') with check (public.my_role() = 'admin');

drop policy if exists "Quản trị gỡ thành viên" on public.members;
create policy "Quản trị gỡ thành viên" on public.members
  for delete to authenticated using (public.my_role() = 'admin' and email <> lower(auth.jwt() ->> 'email'));

-- 5) Quyền truy cập bảng cho trang web
grant usage on schema public to anon, authenticated;
grant select on public.posts to anon, authenticated;
grant insert, update, delete on public.posts to authenticated;
grant select, insert, update, delete on public.members to authenticated;
grant execute on function public.my_role() to anon, authenticated;

-- 6) Quản trị đầu tiên (email của bạn). Đổi email nếu cần.
insert into public.members (email, role) values ('catkhanh1605@gmail.com', 'admin')
on conflict (email) do update set role = 'admin';
